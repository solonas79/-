#include <iostream>
#include <string>
#include <algorithm>

using namespace std;

class Book {
private:
    string title;
    string author;
    int year;
    int id;

public:
    Book() : title(""), author(""), year(0), id(0) {}

    Book(string t, string a, int y, int i)
        : title(t), author(a), year(y), id(i) {}

    string getTitle() const { return title; }
    string getAuthor() const { return author; }
    int getYear() const { return year; }
    int getId() const { return id; }

    void setAuthor(string a) { author = a; }
    void setYear(int y) { year = y; }

    void display() const {
        cout << "ID: " << id
             << ", Τίτλος: " << title
             << ", Συγγραφέας: " << author
             << ", Έτος: " << year << endl;
    }
};

class Library {
private:
    Book* books;
    int size;

public:
    Library() : books(nullptr), size(0) {}

    ~Library() {
        delete[] books;
    }

    void addBook(const Book& b) {
        Book* temp = new Book[size + 1];
        for (int i = 0; i < size; i++)
            temp[i] = books[i];

        temp[size] = b;
        delete[] books;
        books = temp;
        size++;
    }

    void displayBooks() const {
        if (size == 0) {
            cout << "Η βιβλιοθήκη είναι άδεια.\n";
            return;
        }
        for (int i = 0; i < size; i++)
            books[i].display();
    }

    int searchById(int id) const {
        for (int i = 0; i < size; i++)
            if (books[i].getId() == id)
                return i;
        return -1;
    }

    void editBook(int id) {
        int index = searchById(id);
        if (index == -1) {
            cout << "Το βιβλίο δεν βρέθηκε.\n";
            return;
        }

        string newAuthor;
        int newYear;

        cin.ignore();
        cout << "Νέος συγγραφέας: ";
        getline(cin, newAuthor);

        cout << "Νέο έτος: ";
        cin >> newYear;

        books[index].setAuthor(newAuthor);
        books[index].setYear(newYear);

        cout << "Το βιβλίο ενημερώθηκε.\n";
    }

    void deleteBook(int id) {
        int index = searchById(id);
        if (index == -1) {
            cout << "Το βιβλίο δεν βρέθηκε.\n";
            return;
        }

        Book* temp = new Book[size - 1];
        for (int i = 0, j = 0; i < size; i++)
            if (i != index)
                temp[j++] = books[i];

        delete[] books;
        books = temp;
        size--;

        cout << "Το βιβλίο διαγράφηκε.\n";
    }

    void sortByTitle() {
        for (int i = 0; i < size - 1; i++)
            for (int j = 0; j < size - i - 1; j++)
                if (books[j].getTitle() > books[j + 1].getTitle())
                    swap(books[j], books[j + 1]);
    }

    void sortByYear() {
        for (int i = 0; i < size - 1; i++)
            for (int j = 0; j < size - i - 1; j++)
                if (books[j].getYear() > books[j + 1].getYear())
                    swap(books[j], books[j + 1]);
    }
};

int main() {
    Library lib;
    return 0;
}
